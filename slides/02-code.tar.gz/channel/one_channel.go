package main

import "fmt"

func send_to_channel(ch chan int) {
	//sleep
	//print "sending"
	ch <- 1
}

func main() {
	ch := make(chan int)
	go send_to_channel(ch)
	fmt.Println("waiting for sender")
	fmt.Println(<-ch)
}
