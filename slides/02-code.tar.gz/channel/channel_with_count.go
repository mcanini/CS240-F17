package main

import "fmt"

func sum_channels(n int, ch chan int) {
	sum := 1
	for sum < 10 {
		ch <- sum
		sum += sum

	}
	close(ch)
}

func main() {
	ch := make(chan int)
	go sum_channels(10, ch)
	for i := range ch {
		fmt.Println(i)
	}
}
