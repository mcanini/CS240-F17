package main

import (
	"fmt"
	"time"
)

func talk(msg string) {
	for i := 0; ; i++ {
		fmt.Println(msg, i)
		time.Sleep(10 * time.Millisecond)
	}
}

func main() {
	talk("I like to talk")
}
