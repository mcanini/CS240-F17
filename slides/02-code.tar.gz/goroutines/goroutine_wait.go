package main

import (
	"fmt"
	"time"
)

func talk(msg string) {
	for i := 0; ; i++ {
		fmt.Println(msg, i)
		time.Sleep(10 * time.Millisecond)
	}
}

func main() {
	go talk("I like to talk")
	fmt.Println("Oh, people are actually listening")
	time.Sleep(100 * time.Millisecond)
	fmt.Println("People are bored now")

}
