package main

import (
	"fmt"
	"time"
)

func talk(msg string) {
	for i := 0; ; i++ {
		fmt.Println(msg, i)
		time.Sleep(10 * time.Millisecond)
	}
}

func main() {
	go talk("I like to talk!")
	time.Sleep(100 * time.Millisecond)
}
